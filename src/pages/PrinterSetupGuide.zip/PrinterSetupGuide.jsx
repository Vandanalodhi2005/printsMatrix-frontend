// Copilot: Create a UI with the same design style shown earlier:
// - Glassmorphism/modern card layout
// - Smooth spacing and alignment
// - Centered printer icon
// - Big heading, soft subtext
// - Gradient buttons
// Do NOT modify any content. Keep the content exactly the same. Always include: “Do NOT change content/text.”
// Only design/UI changes.
// Design style: Modern, Gradient, Glassmorphism, HP-style.

import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Smartphone, Monitor, Tablet, Printer,
  ChevronRight, ChevronLeft, Wifi, MessageSquare,
  X, Send, CheckCircle2, Power, XCircle, Hourglass,
  ArrowRight, ShieldCheck, Zap, Globe, Cpu, Headphones
} from 'lucide-react';

// ── Custom SVG Icons ───────────────────────────────────────────────────────
const PrinterSVGIcon = ({ badge: Badge, color = "#4f46e5" }) => (
  <div className="relative inline-block group">
    <div className="absolute inset-0 bg-indigo-500/10 blur-xl rounded-full scale-0 group-hover:scale-110 transition-transform duration-500" />
    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" className="text-blue-600 relative z-10" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2" />
      <path d="M6 9V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v5" />
      <rect x="6" y="14" width="12" height="8" rx="1" />
    </svg>
    {Badge && (
      <div className="absolute -bottom-1 -right-1 bg-white p-[2px] rounded-full shadow-sm">
        <Badge size={14} className="text-blue-600" strokeWidth={2.5} />
      </div>
    )}
  </div>
);

const PaperSVGIcon = ({ badge: Badge, color = "#4f46e5" }) => (
  <div className="relative inline-block group">
    <div className="absolute inset-0 bg-indigo-500/10 blur-xl rounded-full scale-0 group-hover:scale-110 transition-transform duration-500" />
    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" className="text-blue-600 relative z-10" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
      <polyline points="14 2 14 8 20 8" />
    </svg>
    {Badge && (
      <div className="absolute -bottom-1 -right-1 bg-white p-[2px] rounded-full shadow-sm">
        <Badge size={14} className="text-blue-600" strokeWidth={2.5} />
      </div>
    )}
  </div>
);

const ScannerSVGIcon = ({ color = "#4f46e5" }) => (
  <div className="relative inline-block group">
    <div className="absolute inset-0 bg-indigo-500/10 blur-xl rounded-full scale-0 group-hover:scale-110 transition-transform duration-500" />
    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" className="text-blue-600 relative z-10" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="10" width="18" height="12" rx="2" />
      <path d="M7 2h10l4 8H3l4-8z" />
      <line x1="8" y1="14" x2="16" y2="14" />
    </svg>
    <div className="absolute -bottom-1 -right-1 bg-white p-[2px] rounded-full shadow-sm">
      <XCircle size={14} className="text-blue-600" strokeWidth={2.5} />
    </div>
  </div>
);

// ── PAGE CONTENT DATA ──────────────────────────────────────────────────────
const pages = [
  {
    id: 1,
    label: "123 HP Com Setup",
    content: (
      <div className="space-y-8 text-slate-600 text-lg leading-relaxed font-light">
        <h2 className="text-3xl md:text-5xl font-black text-slate-900 leading-tight mb-8 tracking-tight">
          123 HP Com Setup – <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-blue-500">Complete Step-by-Step Guide</span> for New Printer Installation
        </h2>
        <p className="bg-white p-6 rounded-2xl border border-indigo-50 shadow-sm border-l-4 border-l-indigo-500">Setting up a new printer should be simple, clear, and frustration-free. If you are searching for 123 hp com setup, you are most likely trying to install your HP printer for the first time, connect it to Wi-Fi, download the correct software, and start printing without delays.</p>
        <p>This guide explains the full setup process in detail so users can understand not only what to do, but also why each step matters. A properly completed printer setup helps prevent later issues such as printer offline errors, driver conflicts, connection failures, and incomplete installation.</p>
        <p>Whether you are setting up a printer for home use, student work, remote office use, or everyday business printing, following the correct sequence can improve performance from the beginning.</p>

        <h2 className="text-2xl font-bold text-slate-900 pt-10 pb-2 border-b-2 border-slate-100 mb-4 flex items-center gap-3">
          <Globe className="text-blue-600" size={24} /> What Is 123 HP Com Setup?
        </h2>
        <p>The term 123 hp com setup is commonly used by users looking for the HP printer setup process. It usually refers to the installation flow for a new HP printer, including driver download, software configuration, wireless setup, and first-time alignment.</p>
        <p>Most users search this keyword when they need help with:</p>
        <ul className="grid grid-cols-1 md:grid-cols-2 gap-4 list-none pl-0">
          {[
            "setting up a brand-new printer",
            "installing printer software on Windows or Mac",
            "connecting the printer to Wi-Fi",
            "printing a test page",
            "fixing setup errors during installation"
          ].map((item, i) => (
            <li key={i} className="flex items-center gap-3 bg-white p-4 rounded-xl text-slate-700 text-sm font-medium border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
              <CheckCircle2 className="text-indigo-500" size={18} /> {item}
            </li>
          ))}
        </ul>
        <p className="pt-4 border-t border-slate-100 mt-6">The goal of this page is to help users complete that setup smoothly with clear step-by-step instructions.</p>

        <h2 className="text-2xl font-bold text-slate-900 pt-10 pb-2 border-b-2 border-slate-100 mb-6 flex items-center gap-3">
          <ShieldCheck className="text-blue-600" size={24} /> Before You Start the Printer Setup
        </h2>
        <p>Before beginning the installation process, it is important to make sure everything needed for setup is ready. Skipping small preparation steps often leads to unnecessary setup interruptions later.</p>
        <p>You should have:</p>
        <ul className="grid grid-cols-1 md:grid-cols-2 gap-4 list-none pl-0">
          {[
            "the printer and power cable",
            "setup ink or toner cartridges",
            "plain white paper",
            "a stable Wi-Fi connection if setting up wirelessly",
            "the printer model number",
            "a computer, laptop, tablet, or smartphone for installation"
          ].map((item, i) => (
            <li key={i} className="flex items-center gap-3 bg-white/40 backdrop-blur-md p-5 rounded-[2rem] text-slate-700 text-sm font-bold border border-white/60 shadow-sm transition-all hover:shadow-lg">
              <Zap className="text-blue-500" size={18} /> {item}
            </li>
          ))}
        </ul>
        <p className="pt-4">If the device is being installed in a home or office environment with multiple Wi-Fi networks, it is also a good idea to confirm which network the printer should use before starting.</p>

        <h2 className="text-2xl font-bold text-slate-900 pt-12 text-center uppercase tracking-widest text-blue-600/50 mb-8 font-black">Physical Configuration Sequence</h2>

        <div className="bg-white/60 backdrop-blur-xl rounded-[3rem] p-12 border border-white/60 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.08)]">
          <h2 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-3">
            <span className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs">1</span> Step 1: Unbox the Printer and Remove Packaging
          </h2>
          <p>The first step in the 123 hp com setup process is physical preparation of the printer.</p>
          <p>Carefully open the box and remove all protective packaging. Most printers include tape, foam inserts, cardboard supports, and internal locks that protect the device during shipping. These materials must be removed fully before the printer is turned on.</p>
          <p className="font-bold text-slate-800 mt-6 mb-2 text-sm uppercase tracking-wider">Pay close attention to:</p>
          <ul className="grid grid-cols-2 gap-3 text-sm text-slate-600">
            {["the scanner lid area", "paper tray packaging", "cartridge access section", "any orange or blue setup tapes", "plastic guards inside moving parts"].map((item, i) => (
              <li key={i} className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-indigo-400" /> {item}
              </li>
            ))}
          </ul>
          <p className="mt-6 text-sm text-slate-500">This step matters because even one small internal packing piece can prevent the printer from initializing properly. If the printer makes unusual noise during startup, it often means something inside was not removed.</p>
          <p className="mt-4">After unpacking, place the printer on a flat and stable surface with enough room for paper loading and ventilation.</p>
        </div>

        <div className="bg-white/60 backdrop-blur-xl rounded-[3rem] p-12 border border-white/60 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.08)] mt-8 relative overflow-hidden">
          <h2 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-3 relative z-10">
            <span className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs">2</span> Step 2: Connect Power and Turn On
          </h2>
          <p className="relative z-10">Once the printer has been unpacked, connect the power cable directly to a reliable wall outlet. It is usually better to avoid loose adapters or unstable power strips during the first setup.</p>
          <p className="relative z-10">Turn the printer on using the power button. The printer may take a few moments to initialize. On models with a display screen, you will usually be asked to select:</p>
          <ul className="grid grid-cols-1 gap-2 mt-4 relative z-10">
            {["Language Selection", "Country or Region", "Time & Basic Preferences"].map((item, i) => (
              <li key={i} className="flex items-center gap-2 text-sm text-slate-600 bg-white p-3 rounded-xl border border-slate-100 shadow-sm">
                <div className="w-1.5 h-1.5 rounded-full bg-indigo-500" /> {item}
              </li>
            ))}
          </ul>
          <p className="mt-6 text-sm text-slate-500 relative z-10">This initial configuration helps the device prepare for software pairing and network setup. During this stage, the printer may also move internal components into position.</p>
        </div>

        <div className="bg-white/60 backdrop-blur-xl rounded-[3rem] p-12 border border-white/60 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.08)] mt-8">
          <h2 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-3">
            <span className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs">3</span> Step 3: Install Setup Cartridges
          </h2>
          <p>After powering on the printer, the next step is installing the cartridges included in the box. New printers are typically shipped with setup cartridges that are meant specifically for first-time installation.</p>
          <p>Open the cartridge access door and wait until the carriage stops moving. Insert each cartridge into the correct slot, making sure it clicks into place securely.</p>
          <div className="bg-white p-5 rounded-2xl mt-6 border border-indigo-100 shadow-sm">
            <p className="font-bold text-indigo-900 text-sm uppercase tracking-wider mb-3">Confirmation indicators:</p>
            <ul className="space-y-2 text-sm text-indigo-800">
              <li className="flex items-center gap-2"><CheckCircle2 size={14} className="text-blue-600" /> Printer confirms installation on screen</li>
              <li className="flex items-center gap-2"><CheckCircle2 size={14} className="text-blue-600" /> Internal priming begins automatically</li>
              <li className="flex items-center gap-2"><CheckCircle2 size={14} className="text-blue-600" /> Request for paper loading</li>
            </ul>
          </div>
          <p className="mt-6 text-sm text-slate-500">This step is important because incorrect placement can cause setup interruptions or poor print quality. If the printer requests alignment, continue to the next step.</p>
        </div>

        <div className="bg-white/60 backdrop-blur-xl rounded-[3rem] p-12 border border-white/60 mt-8 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.08)]">
          <h2 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-3">
            <span className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs">4</span> Step 4: Load Paper & Align
          </h2>
          <p>Most printers require paper to be loaded before the setup can finish.</p>
          <p>Use plain white letter or A4 paper, depending on your region. Adjust the paper guides so the stack is secure but not too tight. Once paper is loaded, the printer may automatically print an alignment page.</p>
          <p className="mt-4">An alignment page helps the device calibrate print quality and cartridge positioning. On some models, you may be asked to place the page on the scanner glass and scan it. This helps improve text sharpness, color placement, and print consistency.</p>
        </div>

        <div className="bg-white/60 backdrop-blur-xl rounded-[3rem] p-12 border border-white/60 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.08)] mt-8 relative overflow-hidden">
          <Wifi className="absolute top-0 right-0 -mr-10 -mt-10 text-blue-600 opacity-5" size={240} />
          <h2 className="text-2xl font-black mb-6 flex items-center gap-4 relative z-10">
            <span className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm font-bold shadow-lg">5</span> Step 5: Wireless Connectivity
          </h2>
          <p className="text-slate-600 mb-8 relative z-10">For most users, wireless setup is the preferred option because it allows printing from multiple devices without keeping the printer connected by cable.</p>
          <ul className="space-y-4 relative z-10">
            {[
              "Open wireless settings on the control panel",
              "Execute Wireless Setup Wizard",
              "Select your network (SSID)",
              "Input Wi-Fi password carefully",
              "Confirm successful connection status"
            ].map((step, i) => (
              <li key={i} className="flex items-center gap-4 bg-white p-4 rounded-2xl border border-slate-100 shadow-sm">
                <div className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-[10px] font-bold">{i+1}</div>
                <span className="text-sm font-medium text-slate-700">{step}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="bg-white/60 backdrop-blur-xl rounded-[3rem] p-12 border border-white/60 mt-8 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.08)]">
          <h2 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-3">
            <span className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs">6</span> Step 6: Software & Drivers
          </h2>
          <p>Once the printer is connected to the network, the next stage of the 123 hp com setup process is software installation.</p>
          <p>This software helps your computer communicate with the printer correctly. It also enables features like:</p>
          <ul className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-4">
            {["printing", "scanning", "device management", "ink level monitoring", "firmware updates", "wireless setup assistance"].map((item, i) => (
              <li key={i} className="flex items-center gap-2 text-xs font-bold text-slate-500 uppercase tracking-tighter bg-white p-3 rounded-lg border border-slate-100 shadow-sm">
                <CheckCircle2 className="text-indigo-500" size={14} /> {item}
              </li>
            ))}
          </ul>
          <p className="mt-6 text-sm text-slate-500">Using the correct driver is important because a generic or outdated driver can lead to limited functionality or printing errors later.</p>
        </div>

        <div className="bg-white/60 backdrop-blur-xl rounded-[3rem] p-12 border border-white/60 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.08)] mt-8">
          <h2 className="text-xl font-bold mb-4 flex items-center gap-3 text-slate-900">
            <span className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs font-bold">7</span> Step 7: Final Installation
          </h2>
          <p className="text-slate-600">After downloading the software, open the installer and follow the on-screen instructions. The setup program will usually ask how you want to connect the printer, such as:</p>
          <ul className="grid grid-cols-3 gap-2 my-4">
            {["Wireless", "USB", "Network"].map((item, i) => (
              <li key={i} className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-center text-sm font-bold text-slate-700">
                {item}
              </li>
            ))}
          </ul>
          <p className="text-slate-600">Choose the connection type that matches how your printer is set up. If the printer is already connected to Wi-Fi, the installer should search for available printers on the network.</p>
          <p className="mt-4">Once your printer appears, select it and continue. The installer may:</p>
          <ul className="grid grid-cols-2 gap-3 mt-4">
            {["finish driver installation", "add the printer to your device", "configure printing preferences", "install scanner utilities if supported"].map((item, i) => (
              <li key={i} className="flex items-center gap-2 text-xs bg-blue-50/50 p-3 rounded-xl border border-blue-100/50 text-indigo-700 font-medium">
                <ArrowRight size={14} className="text-blue-600" /> {item}
              </li>
            ))}
          </ul>
          <p className="mt-6 text-sm text-slate-500">At the end of the installation, most systems offer a test print option. It is a good idea to use it immediately. A successful test page confirms that the device, driver, and connection are all working together correctly.</p>
        </div>

        <div className="bg-white/60 backdrop-blur-xl rounded-[3rem] p-12 border border-white/60 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.08)] mt-16 relative overflow-hidden">
          <h2 className="text-3xl font-black mb-10 flex items-center gap-4 relative z-10 uppercase tracking-tighter text-slate-900">
            Troubleshooting Protocols
          </h2>
          <p className="text-slate-500 mb-8 relative z-10">Even when the overall process is simple, some users may still run into setup issues. Understanding the reason behind each problem makes troubleshooting easier.</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 relative z-10">
            {[
              { title: "Printer Not Detected", desc: "This usually happens when the units share network frequencies. Restarting units often refreshes the handshake." },
              { title: "Wi-Fi Setup Failed", desc: "Validate credentials and minimize physical signal interference or router distance." },
              { title: "Driver Initialization", desc: "Purge legacy software files and re-execute the installer for fresh driver registration." },
              { title: "Alignment Errors", desc: "Validate setup cartridge levels and execute manual alignment sequence on glass if required." }
            ].map((item, i) => (
              <div key={i} className="space-y-4 border-l-4 border-indigo-500/10 hover:border-indigo-500/40 transition-colors pl-6">
                <h3 className="font-bold text-blue-600 uppercase text-xs tracking-widest">{item.title}</h3>
                <p className="text-sm text-slate-600 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-12 p-8 bg-white rounded-3xl border border-indigo-100 shadow-sm flex items-center gap-6">
          <div className="p-4 bg-white rounded-2xl shadow-sm text-blue-600">
            <Headphones size={32} />
          </div>
          <div>
            <h3 className="font-bold text-indigo-900 mb-1">Tips for a Professional Setup</h3>
            <p className="text-indigo-800/70 text-sm">Keep the printer near the router, avoid guest Wi-Fi networks, and ensure your operating system is updated for driver compatibility.</p>
          </div>
        </div>
      </div>
    ),
  },
  {
    id: 2,
    label: "HP Printer Setup & Install",
    content: (
      <div className="space-y-8 text-slate-600 text-lg leading-relaxed font-light">
        <h2 className="text-3xl md:text-5xl font-black text-slate-900 leading-tight mb-8 tracking-tight">
          HP Printer Setup &amp; Install – <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-500">Professional Deployment</span> for Optimized Performance
        </h2>
        <p className="bg-white p-8 rounded-3xl border border-slate-200 border-l-8 border-l-indigo-600 shadow-sm leading-relaxed">If you are searching for hp printer setup &amp; install, you most likely want a complete guide that explains how to prepare your printer, connect it to your device, install the correct software, and start using it without confusion.</p>
        <p>Printer installation is not only about turning the device on and downloading a driver. A successful setup includes physical preparation, connection setup, software installation, system detection, and a final test to confirm everything is working as expected.</p>
        <p>This page is written as a complete standalone installation guide for users who want a clear and detailed explanation from start to finish.</p>

        <h2 className="text-2xl font-bold text-slate-900 pt-10 pb-2 border-b-2 border-slate-100 mb-4 flex items-center gap-3">
          <Cpu className="text-blue-600" size={24} /> Understanding HP Printer Setup and Installation
        </h2>
        <p>Printer setup and printer installation are closely related, but they are not exactly the same thing.</p>
        <p className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm leading-relaxed"><strong>Printer setup</strong> usually refers to preparing the hardware, adding cartridges, loading paper, connecting the printer to Wi-Fi or USB, and completing the printer's on-device configuration.</p>
        <p className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm leading-relaxed"><strong>Printer installation</strong> usually refers to adding the printer to a computer, downloading the correct software, installing the driver, and enabling print and scan functions.</p>
        <p className="pt-4">A good landing page for this keyword should cover both, because users searching hp printer setup &amp; install generally want the complete process, not just one part of it.</p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 my-10">
          <div className="bg-white/40 backdrop-blur-md p-8 rounded-[2rem] border border-white/40 shadow-sm hover:shadow-xl transition-all">
            <h3 className="text-xl font-bold text-blue-600 mb-3 flex items-center gap-2">
              <Wifi size={20} /> Wireless Setup
            </h3>
            <p className="text-sm">Ideal for users who want to print from laptops, smartphones, or multiple devices. It gives more flexibility and avoids physical cable dependence.</p>
          </div>
          <div className="bg-white/40 backdrop-blur-md p-8 rounded-[2rem] border border-white/40 shadow-sm hover:shadow-xl transition-all">
            <h3 className="text-xl font-bold text-blue-600 mb-3 flex items-center gap-2">
              <ArrowRight size={20} /> USB Setup
            </h3>
            <p className="text-sm">Preferred when the printer is located close to a computer or when the network connection is unstable. Helpful for first-time troubleshooting.</p>
          </div>
        </div>

        <div className="bg-white/60 backdrop-blur-xl rounded-[3rem] p-12 border border-white/60 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.08)]">
          <h2 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-3">
            <span className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs">1</span> Step 1: Prepare the Printer for Setup
          </h2>
          <p>Start by unpacking the printer and removing all internal and external packaging materials. Place the printer on a stable surface and connect the power cable.</p>
          <p className="mt-4">When the printer turns on for the first time, it usually prompts you to confirm basic preferences such as language and region. These settings are part of the setup process and should be completed before trying to install the software on your device.</p>
          <div className="bg-white/40 backdrop-blur-md p-6 rounded-[2rem] border border-white/60 mt-6 shadow-sm">
            <p className="font-bold text-indigo-900 text-sm uppercase mb-3 px-2 tracking-widest">Pre-installation checklist:</p>
            <ul className="grid grid-cols-2 gap-2">
              {["cartridges are ready to install", "paper is available", "computer or mobile device is nearby", "Wi-Fi password is ready"].map((item, i) => (
                <li key={i} className="flex items-center gap-2 text-xs font-bold text-slate-500 bg-white p-3 rounded-xl border border-slate-100 shadow-sm">
                  <CheckCircle2 className="text-indigo-500" size={14} /> {item}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="bg-white/60 backdrop-blur-xl rounded-[3rem] p-12 border border-white/60 mt-8 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.08)]">
          <h2 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-3">
            <span className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs">2</span> Step 2: Install Ink or Toner and Load Paper
          </h2>
          <p>The next stage of hp printer setup &amp; install is preparing the printer internally.</p>
          <p>Open the cartridge access area and insert the setup cartridges or toner included with the device. Wait for the printer to recognize them and complete any automatic initialization.</p>
          <p>After that, load plain white paper into the input tray. Some printers will print an alignment page automatically during first-time setup. This page may need to be scanned or confirmed depending on the printer model.</p>
          <p className="mt-6 text-sm text-slate-500">This stage is essential because incomplete cartridge installation or missing paper can interrupt the rest of the setup process.</p>
        </div>

        <div className="bg-white/60 backdrop-blur-xl rounded-[3rem] p-12 border border-white/60 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.08)] mt-8 relative overflow-hidden">
          <h2 className="text-2xl font-black mb-6 flex items-center gap-4 relative z-10 uppercase tracking-tighter">
            <span className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm font-bold shadow-lg">3</span> Step 3: Connect Wireless or USB
          </h2>
          <p className="text-slate-600 mb-6 relative z-10">Use the printer control panel to open network settings and connect the printer to your Wi-Fi network. Enter the password carefully and wait until the connection is confirmed.</p>
          <div className="bg-white/40 backdrop-blur-md p-6 rounded-[2rem] border border-white/60 relative z-10 shadow-sm">
            <p className="text-sm font-bold mb-3 text-indigo-900 uppercase tracking-wider">For USB Connection Setup:</p>
            <p className="text-sm text-slate-600 font-light leading-relaxed">If you are using USB, connect the cable only when the installation software asks you to. Plugging it in too early can sometimes cause the system to install a generic driver instead of the intended software package.</p>
          </div>
          <p className="mt-6 text-sm text-slate-500 font-light relative z-10">The connection method you choose affects how the rest of the installation proceeds, so it is important to follow the right instructions for that method.</p>
        </div>

        <div className="bg-white/60 backdrop-blur-xl rounded-[3rem] p-12 border border-white/60 mt-8 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.08)]">
          <h2 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-3">
            <span className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs">4</span> Step 4: Download Driver and Software
          </h2>
          <p>Printer software allows the operating system to communicate with the printer correctly. Without the right software, the printer might appear installed but not work properly for advanced features such as scanning, device status reporting, or wireless management.</p>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3 my-6">
            {["print driver", "scan software", "utility tools", "device management", "update tools"].map((item, i) => (
              <div key={i} className="flex items-center gap-2 text-xs font-bold text-blue-600 bg-white p-3 rounded-xl border border-indigo-100 shadow-sm">
                <CheckCircle2 size={14} /> {item}
              </div>
            ))}
          </div>
          <p className="mt-4 text-sm text-slate-500">This step is one of the most important parts of the hp printer setup &amp; install process because driver compatibility directly affects printer performance.</p>
        </div>

        <div className="bg-white/60 backdrop-blur-xl rounded-[3rem] p-12 border border-white/60 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.08)] mt-8 relative overflow-hidden">
          <h2 className="text-2xl font-black mb-6 flex items-center gap-4 relative z-10 uppercase tracking-tighter text-slate-900">
            <span className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm font-bold shadow-lg">5</span> Step 5: Run the Installer
          </h2>
          <p className="text-slate-500 mb-8 relative z-10 font-medium">After downloading the software, open the setup file and start the installation wizard. The installer will usually ask you to accept terms, choose connection type, and detect your printer.</p>
          <p className="text-sm font-light text-slate-500">If the printer is detected properly, continue until the setup is complete. If not, the software may offer troubleshooting steps such as checking the connection, restarting the printer, or trying a different method.</p>
        </div>

        <div className="bg-white/60 backdrop-blur-xl rounded-[3rem] p-12 border border-white/60 mt-8 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.08)]">
          <h2 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-3">
            <span className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs">6</span> Step 6: Final Test & Confirmation
          </h2>
          <p>After installation, confirm accuracy by printing a test page. This helps catch small issues before the printer is used for important documents.</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
            {[
              "Driver status verification",
              "Communication path test",
              "Paper handling check",
              "Scanner utility confirmation"
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-3 bg-white p-4 rounded-xl border border-slate-100 shadow-sm">
                <CheckCircle2 className="text-blue-600" size={18} />
                <span className="text-sm font-medium text-slate-700">{item}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white/60 backdrop-blur-xl rounded-[3rem] p-12 border border-white/60 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.08)] mt-16 relative overflow-hidden">
          <h2 className="text-3xl font-black mb-10 flex items-center gap-4 uppercase tracking-tighter text-slate-900">
            Performance Optimization
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-4 border-l-4 border-indigo-500/10 hover:border-indigo-500/40 transition-colors pl-6">
              <h3 className="font-bold text-blue-600 uppercase text-xs tracking-widest">Why Setup & Install Matters</h3>
              <p className="text-sm leading-relaxed text-slate-600 font-medium">A professional hp printer setup &amp; install ensures high print quality, prevents the "printer offline" status, and enables full scanning capability.</p>
            </div>
            <div className="space-y-4 border-l-4 border-indigo-500/10 hover:border-indigo-500/40 transition-colors pl-6">
              <h3 className="font-bold text-blue-600 uppercase text-xs tracking-widest">Long-term Reliability</h3>
              <p className="text-sm leading-relaxed text-slate-600 font-medium">Keep the printer software updated and use a stable Wi-Fi network. These habits help reduce connection drops and offline errors.</p>
            </div>
          </div>
        </div>
      </div>
    ),
  },
  {
    id: 3,
    label: "HP Printer Offline Fix",
    content: (
      <div className="space-y-8 text-slate-600 text-lg leading-relaxed font-light">
        <h2 className="text-3xl md:text-5xl font-black text-slate-900 leading-tight mb-8 tracking-tight">
          HP Printer Offline Fix – <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-blue-500">Restore Critical Connectivity</span>
        </h2>
        <p className="bg-white p-8 rounded-3xl border border-indigo-100 border-l-8 border-l-indigo-600 shadow-sm leading-relaxed">Seeing an offline printer message can be frustrating, especially when the printer appears powered on and ready. In many cases, the cause is not the printer itself but a communication problem between the printer, operating system, Wi-Fi network, or print queue.</p>
        <p>This page explains the offline problem in detail and gives clear steps to bring the printer back online.</p>

        <div className="bg-white/60 backdrop-blur-xl rounded-[3rem] p-12 border border-white/60 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.08)] relative overflow-hidden mb-12">
          <h2 className="text-2xl font-black mb-6 flex items-center gap-4 relative z-10 uppercase tracking-tighter text-slate-900">
            What Does "Printer Offline" Mean?
          </h2>
          <p className="text-slate-500 mb-8 relative z-10 font-medium">When a printer shows as offline, it usually means the computer cannot send print jobs to it successfully. This can happen because of:</p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 relative z-10">
            {["network interruptions", "incorrect status settings", "stuck print queue", "outdated drivers", "IP address changes", "system confusion"].map((item, i) => (
              <div key={i} className="flex items-center gap-3 bg-white p-4 rounded-xl border border-slate-100 shadow-sm">
                <div className="w-1.5 h-1.5 rounded-full bg-blue-600 shadow-[0_0_8px_rgba(79,70,229,0.3)]" />
                <span className="text-xs font-medium text-slate-700">{item}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white/60 backdrop-blur-xl rounded-[3rem] p-12 border border-white/60 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.08)]">
          <h2 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-3">
            <span className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs">1</span> Step 1: Hardware Status Validation
          </h2>
          <p>Before changing any settings, check the printer itself. Look at the control panel or display and confirm that power is on, no error messages exist, and paper/cartridges are installed. A printer that is stuck on an internal error screen will many times report as offline to the OS.</p>
        </div>

        <div className="bg-white/60 backdrop-blur-xl rounded-[3rem] p-12 border border-white/60 mt-8 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.08)]">
          <h2 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-3">
            <span className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs">2</span> Step 2: Connection Verification
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
            <div className="p-6 bg-white/40 backdrop-blur-md rounded-[2rem] border border-white/60 shadow-sm">
              <h3 className="font-bold text-indigo-900 mb-2 flex items-center gap-2 small-caps">Wireless Protocol</h3>
              <p className="text-sm">Ensure printer and computer share the same SSID. Address switches after router restarts are a common culprit.</p>
            </div>
            <div className="p-6 bg-white/40 backdrop-blur-md rounded-[2rem] border border-white/60 shadow-sm">
              <h3 className="font-bold text-indigo-900 mb-2 flex items-center gap-2 small-caps">USB Protocol</h3>
              <p className="text-sm">Verify physical seating. Power-cycle the USB hub or switch ports to refresh the hardware handshake.</p>
            </div>
          </div>
        </div>

        <div className="bg-white/60 backdrop-blur-xl rounded-[3rem] p-12 border border-white/60 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.08)] mt-8 relative overflow-hidden">
          <h2 className="text-2xl font-black mb-6 flex items-center gap-4 relative z-10 uppercase tracking-tighter text-slate-900">
            <span className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm font-bold shadow-lg">3-4</span> Priority System Fixes
          </h2>
          <div className="space-y-6 relative z-10">
            <div className="bg-blue-50/50 p-6 rounded-2xl border border-indigo-100">
              <h3 className="font-bold mb-2 text-slate-900">Set as Default</h3>
              <p className="text-sm text-slate-600">Ensure the correct device instance is chosen. Re-installation often creates duplicates.</p>
            </div>
            <div className="bg-blue-50/50 p-6 rounded-2xl border border-indigo-100">
              <h3 className="font-bold mb-2 text-slate-900">Disable "Use Printer Offline"</h3>
              <p className="text-sm text-slate-600">Check queue settings to ensure the system isn't intentionally withholding data.</p>
            </div>
          </div>
        </div>

        <div className="bg-white/60 backdrop-blur-xl rounded-[3rem] p-12 border border-white/60 mt-8 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.08)]">
          <h2 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-3">
            <span className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs">5-6</span> Queue & Power Protocols
          </h2>
          <p>Clear the print queue to remove corrupted jobs. Follow this with a full power cycle of the printer, computer, and router. A clean restart refreshes memory and IP assignments, solving many temporary communication failures.</p>
        </div>

        <div className="bg-white/60 backdrop-blur-xl rounded-[3rem] p-12 border border-white/60 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.08)] mt-8 relative overflow-hidden">
          <h2 className="text-2xl font-black mb-6 flex items-center gap-4 relative z-10 uppercase tracking-tighter text-slate-900">
            <span className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm font-bold shadow-lg">7-9</span> Advanced Resolution
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 relative z-10">
            <div className="space-y-4 border-l-4 border-indigo-500/10 hover:border-indigo-500/40 transition-colors pl-4">
              <h4 className="text-xs font-bold text-blue-600 uppercase tracking-widest">IP Strategy</h4>
              <p className="text-[10px] text-slate-500 leading-relaxed font-medium">Confirm current IP on the network configuration page. Assign static IP for stability.</p>
            </div>
            <div className="space-y-4 border-l-4 border-indigo-500/10 hover:border-indigo-500/40 transition-colors pl-4">
              <h4 className="text-xs font-bold text-blue-600 uppercase tracking-widest">Driver Refresh</h4>
              <p className="text-[10px] text-slate-500 leading-relaxed font-medium">Purge and reinstall drivers to fix corruption after system updates.</p>
            </div>
            <div className="space-y-4 border-l-4 border-indigo-500/10 hover:border-indigo-500/40 transition-colors pl-4">
              <h4 className="text-xs font-bold text-blue-600 uppercase tracking-widest">Spooler Reset</h4>
              <p className="text-[10px] text-slate-500 leading-relaxed font-medium">Restart the print spooler service to clear system-level processing delays.</p>
            </div>
          </div>
        </div>

        <div className="mt-12 p-8 bg-white rounded-3xl border border-indigo-100 shadow-sm flex items-center gap-6">
          <div className="p-4 bg-white rounded-2xl shadow-sm text-blue-600">
            <ShieldCheck size={32} />
          </div>
          <div>
            <h3 className="font-bold text-indigo-900 mb-1">Preventive Care</h3>
            <p className="text-indigo-800/70 text-sm">Assign static IPs, keep drivers current, and avoid frequent SSID switches to maintain a robust connection.</p>
          </div>
        </div>
      </div>
    ),
  },
  {
    id: 4,
    label: "HP Printer Troubleshooting",
    content: (
      <div className="space-y-5 text-gray-600 text-lg leading-relaxed">
        <h2 className="text-3xl md:text-4xl font-bold text-gray-900 leading-tight">
          HP Printer Troubleshooting – Complete Guide to Fix Common Printer Problems
        </h2>
        <p>Printers are essential for daily work, school tasks, office paperwork, shipping labels, scanning, and document handling. When a printer stops working as expected, even a small issue can interrupt productivity.</p>
        <p>If you are searching for hp printer troubleshooting, you likely need a detailed guide that explains how to identify and solve common printer problems such as printing failures, poor print quality, connection errors, scanner issues, or software conflicts.</p>
        <p>This page is built as a complete troubleshooting resource, organized by problem type so users can quickly understand the issue and follow the right fix.</p>

        <div className="bg-white/60 backdrop-blur-xl rounded-[3rem] p-12 border border-white/60 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.08)] mt-16 pb-12">
          <h2 className="text-xl font-bold text-slate-900 mb-6 flex items-center gap-3 lowercase tracking-tighter">
            Troubleshooting Architecture
          </h2>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {["setup/install", "not printing", "print quality", "network/wifi", "offline status", "scanner fix", "driver/software", "hardware/paper"].map((item, i) => (
              <div key={i} className="flex items-center gap-2 text-[10px] font-black text-blue-600 uppercase tracking-widest bg-white p-3 rounded-xl border border-indigo-100 shadow-sm hover:shadow-md transition-shadow">
                <ShieldCheck size={12} /> {item}
              </div>
            ))}
          </div>
          <p className="mt-8 text-sm text-slate-500 font-medium">When users understand which category the issue belongs to, they can solve it faster and avoid unnecessary reinstallation or repeated resets.</p>
        </div>

        <div className="space-y-12">
          <div className="bg-white/60 backdrop-blur-xl rounded-[2.5rem] p-8 border border-white/40 shadow-2xl shadow-slate-200/50 group h-full relative overflow-hidden hover:border-indigo-200 transition-all">
            <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity"><Printer size={80} /></div>
            <h3 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-3">
              <span className="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center text-xs">1</span> Printer Not Printing
            </h3>
            <p className="mb-6 text-sm">One of the most common printer issues is when the printer appears ready, but nothing prints. This can happen because the wrong printer is selected, the queue is stuck, or the driver is not responding.</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-white rounded-2xl border border-slate-100 shadow-sm">
                <p className="text-xs font-bold text-blue-600 mb-2 small-caps">Diagnosis</p>
                <p className="text-xs text-slate-500">Check power/ready status, select correct device, verify paper levels.</p>
              </div>
              <div className="p-4 bg-white rounded-2xl border border-slate-100 shadow-sm">
                <p className="text-xs font-bold text-blue-600 mb-2 small-caps">Resolution</p>
                <p className="text-xs text-slate-500">Restart printer, send a fresh test page to bypass document corruption.</p>
              </div>
            </div>
          </div>

          <div className="bg-white/60 backdrop-blur-xl rounded-[3rem] p-12 border border-white/60 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.08)] group hover:border-indigo-200 transition-all">
             <h3 className="text-xl font-bold mb-4 flex items-center gap-3">
              <span className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs">2</span> Poor Print Quality
            </h3>
            <p className="mb-6 text-slate-600 text-sm font-medium">Faded text, blurry output, missing colors, streaks, or smudges. Often related to supply levels, clogged printheads, or alignment issues.</p>
            <ul className="grid grid-cols-2 gap-3">
              {["Check Supply Levels", "Run Cleaning Cycle", "Complete Alignment", "Review Settings"].map((item, i) => (
                <li key={i} className="flex items-center gap-2 text-[10px] font-bold bg-blue-50/50 p-3 rounded-xl border border-blue-100/50 text-indigo-700">
                  <CheckCircle2 size={12} className="text-blue-600" /> {item}
                </li>
              ))}
            </ul>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white/40 backdrop-blur-md p-8 rounded-[2rem] border border-white/40 shadow-sm">
              <h3 className="font-bold text-slate-900 mb-3 flex items-center gap-2 small-caps"><Wifi size={18} className="text-blue-600"/> Wireless Failures</h3>
              <p className="text-xs leading-relaxed text-slate-500 mb-4">Connection drops after sleep, slow detection, or disappearing from the network. Confirm signal strength and sharing of the same SSID.</p>
              <div className="text-[10px] font-bold text-blue-600 uppercase tracking-widest">Solution: Minimize router distance and verify frequency stability.</div>
            </div>
            <div className="bg-white/40 backdrop-blur-md p-8 rounded-[2rem] border border-white/40 shadow-sm">
              <h3 className="font-bold text-slate-900 mb-3 flex items-center gap-2 small-caps"><Cpu size={18} className="text-blue-600"/> Driver Corruption</h3>
              <p className="text-xs leading-relaxed text-slate-500 mb-4">Missing scan functions, incomplete installation, or advanced settings not appearing after system updates.</p>
              <div className="text-[10px] font-bold text-blue-600 uppercase tracking-widest">Solution: Reinstall full feature software package.</div>
            </div>
          </div>

          <div className="bg-white/40 backdrop-blur-md p-8 rounded-[2rem] border border-white/40 shadow-sm">
            <h3 className="text-xl font-bold text-slate-900 mb-6 flex items-center gap-3 tracking-tighter border-b pb-4">Specialized Diagnostics</h3>
            <div className="space-y-8">
              <div className="flex gap-6">
                <div className="w-12 h-12 rounded-2xl bg-indigo-50 flex items-center justify-center text-blue-600 shrink-0"><ShieldCheck /></div>
                <div>
                  <h4 className="font-bold text-slate-900 mb-1">Scanner Failures</h4>
                  <p className="text-sm text-slate-500">Printing works but scanning does not. Often due to partial driver installation. Verify permissions and software utility status.</p>
                </div>
              </div>
              <div className="flex gap-6">
                <div className="w-12 h-12 rounded-2xl bg-white/50 backdrop-blur-md flex items-center justify-center text-blue-600 shrink-0 border border-white/30"><ArrowRight /></div>
                <div>
                  <h4 className="font-bold text-slate-900 mb-1">Paper Feed Errors</h4>
                  <p className="text-sm text-slate-500">Jams, crooked feeds, or multi-sheet pickups. Remove jams carefully and adjust tray guides for perfect alignment.</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white p-10 rounded-3xl text-slate-900 border border-slate-200 shadow-sm relative overflow-hidden">
             <h3 className="text-3xl font-black mb-8 flex items-center gap-4 uppercase tracking-tighter text-slate-900">
              Performance Protocols
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              <div className="space-y-4 border-l-4 border-indigo-500/10 hover:border-indigo-500/40 transition-colors pl-6">
                <h4 className="text-xs font-bold text-blue-600 uppercase tracking-widest">Queue Clearing</h4>
                <p className="text-xs text-slate-500 leading-relaxed font-medium">A stuck queue blocks new jobs. Clear all pending status and restart the spooler service to restore normal flow.</p>
              </div>
              <div className="space-y-4 border-l-4 border-indigo-500/10 hover:border-indigo-500/40 transition-colors pl-6">
                <h4 className="text-xs font-bold text-blue-600 uppercase tracking-widest">Delayed Response</h4>
                <p className="text-xs text-slate-500 leading-relaxed font-medium">Slow wake-up or long print delays. Reduce file complexity and verify network traffic levels for optimal results.</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white/60 backdrop-blur-xl rounded-[3rem] p-12 border border-white/60 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.08)] flex items-center gap-6 mt-16">
          <div className="p-4 bg-blue-600 rounded-2xl shadow-lg text-white">
            <CheckCircle2 size={32} />
          </div>
          <div>
            <h3 className="font-bold text-slate-900 mb-1">The Standard Troubleshooting Routine</h3>
            <p className="text-slate-500 text-sm font-medium">Physical status &rarr; Connection status &rarr; Queue status &rarr; Restart protocol &rarr; Software reinstall.</p>
          </div>
        </div>
      </div>
    ),
  },
  {
    id: 5,
    label: "HP Printer Not Printing",
    content: (
      <div className="space-y-8 text-slate-600 text-lg leading-relaxed font-light">
        <h2 className="text-3xl md:text-5xl font-black text-slate-900 leading-tight mb-8 tracking-tight">
          HP Printer Not Printing – <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-blue-500">Restore Output Intelligence</span>
        </h2>
        <p className="bg-white p-8 rounded-3xl border border-indigo-100 border-l-8 border-l-indigo-600 shadow-sm leading-relaxed">If you are searching for hp printer not printing, you are likely dealing with one of the most common printer issues users face. The printer may be powered on, connected to your computer or Wi-Fi, and appear ready, but when you send a document, nothing prints. In some cases, the print job stays stuck in the queue. In others, the printer acts as if it received the command but does not respond.</p>
        <p>This issue can happen for many reasons, including connection problems, incorrect printer settings, low or unrecognized cartridges, paper feed issues, software conflicts, or print spooler errors. The good news is that most of these problems can be fixed by following the right troubleshooting sequence.</p>
        <p>This page explains the issue in detail and gives a full step-by-step process to help restore printing properly.</p>

        <div className="bg-white/60 backdrop-blur-xl rounded-[3rem] p-12 border border-white/60 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.08)] relative overflow-hidden mb-12">
          <h2 className="text-2xl font-black mb-6 flex items-center gap-4 relative z-10 uppercase tracking-tighter text-slate-900">
            Why Is My HP Printer Not Printing?
          </h2>
          <p className="text-slate-500 mb-8 relative z-10 font-medium">When a printer stops printing, the cause is not always obvious right away. A printer may stop printing because of:</p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 relative z-10">
            {["unstable connection", "wrong printer selected", "stuck print queue", "offline printer status", "low/empty cartridges", "paper jam obstruction", "outdated drivers", "spooler interruptions", "settings mismatch"].map((item, i) => (
              <div key={i} className="flex items-center gap-3 bg-white p-4 rounded-xl border border-slate-100 shadow-sm">
                <div className="w-1.5 h-1.5 rounded-full bg-blue-600" />
                <span className="text-xs font-medium text-slate-700">{item}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white/60 backdrop-blur-xl rounded-[3rem] p-12 border border-white/60 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.08)]">
          <h2 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-3 lowercase font-bold">Start With the Basics</h2>
          <p>Before moving into detailed fixes, check power, warning messages, paper loading, and connection status. If the printer display shows a paper jam, cartridge issue, or attention warning, solve that first before checking computer settings.</p>
        </div>

        <div className="space-y-12 my-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-white/40 backdrop-blur-md p-8 rounded-[2rem] border border-white/40 shadow-sm">
              <h3 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-3">
                <span className="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center text-xs">1</span> Printer Ready State
              </h3>
              <p className="text-sm mb-4">Confirm readiness by checking blinking warning lights, low ink alerts, or door status. Software troubleshooting will not help if the printer is paused by a hardware condition.</p>
            </div>
            <div className="bg-white/40 backdrop-blur-md p-8 rounded-[2rem] border border-white/40 shadow-sm">
              <h3 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-3">
                <span className="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center text-xs">2</span> Connection Diagnostics
              </h3>
              <p className="text-sm mb-4">Validate Wi-Fi SSID parity or USB cable seating. A weak or broken connection may allow the printer to appear installed while still preventing successful printing.</p>
            </div>
          </div>

          <div className="bg-white/60 backdrop-blur-xl rounded-[3rem] p-12 border border-white/60 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.08)] group hover:border-indigo-200 transition-all">
            <h3 className="text-xl font-bold mb-6 flex items-center gap-3">
              <span className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs">3-4</span> Priority System Configuration
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-4 border-l-4 border-indigo-500/10 hover:border-indigo-500/40 transition-colors pl-4">
                <p className="text-sm font-bold uppercase tracking-widest text-blue-600">Printer Selection</p>
                <p className="text-sm text-slate-600">Confirm the intended printer is selected in the print dialog. Set as default to avoid routing confusion.</p>
              </div>
              <div className="space-y-4 border-l-4 border-indigo-500/10 hover:border-indigo-500/40 transition-colors pl-4">
                <p className="text-sm font-bold uppercase tracking-widest text-blue-600">Status Override</p>
                <p className="text-sm text-slate-600">Open the print queue and ensure "Use Printer Offline" is disabled and the queue is not paused.</p>
              </div>
            </div>
          </div>

          <div className="bg-white/40 backdrop-blur-md p-8 rounded-[2rem] border border-white/40 shadow-sm">
            <h3 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-3">
              <span className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs">5</span> Queue & Spooler Reset
            </h3>
            <p className="text-sm">Cancel all pending documents in the print queue. A single corrupted document can block everything behind it. If the queue refuses to clear, restart the print spooler service.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white/40 backdrop-blur-md p-8 rounded-[2rem] border border-white/40 shadow-sm">
              <h3 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-3">
                <span className="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center text-xs">6</span> Paper Path Integrity
              </h3>
              <p className="text-sm mb-4">Reload paper neatly and adjust guides. Inspect for hidden scraps from previous jams. A clean reload often fixes issues mistaken for software problems.</p>
            </div>
            <div className="bg-white/40 backdrop-blur-md p-8 rounded-[2rem] border border-white/40 shadow-sm">
              <h3 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-3">
                <span className="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center text-xs">7</span> Cartridge Reliability
              </h3>
              <p className="text-sm mb-4">Check seating, verify tape removal on new units, and observe for supply warnings. Reseat or replace if not detected.</p>
            </div>
          </div>

          <div className="bg-white p-10 rounded-3xl text-slate-900 border border-slate-200 shadow-sm relative overflow-hidden">
             <h3 className="text-2xl font-black mb-8 flex items-center gap-4 uppercase tracking-tighter text-slate-900">
              Restoration Protocols
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="space-y-4 border-l-4 border-indigo-500/10 hover:border-indigo-500/40 transition-colors pl-4">
                <h4 className="text-xs font-bold text-blue-600 uppercase tracking-widest">Power Cycle</h4>
                <p className="text-[10px] text-slate-500 leading-relaxed font-medium">Turn off units, restart router, then re-power in sequence: Router &rarr; Printer &rarr; Computer.</p>
              </div>
              <div className="space-y-4 border-l-4 border-indigo-500/10 hover:border-indigo-500/40 transition-colors pl-4">
                <h4 className="text-xs font-bold text-blue-600 uppercase tracking-widest">Test Print</h4>
                <p className="text-[10px] text-slate-500 leading-relaxed font-medium">Print directly from system settings to isolate whether the issue is file-specific or printer-wide.</p>
              </div>
              <div className="space-y-4 border-l-4 border-indigo-500/10 hover:border-indigo-500/40 transition-colors pl-4">
                <h4 className="text-xs font-bold text-blue-600 uppercase tracking-widest">Driver Refresh</h4>
                <p className="text-[10px] text-slate-500 leading-relaxed font-medium">Download latest software package. This is critical after operating system or network changes.</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white/60 backdrop-blur-xl rounded-[3rem] p-12 border border-white/60 mt-8 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.08)]">
          <h2 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-3 lowercase">Step 11-12: Service Logs & Status</h2>
          <p>Restart the print spooler service to clear processing bottlenecks. If the issue continues, review the device display for specific error codes like "carriage jam" or "service required". Addressing specific alerts is more effective than generic troubleshooting.</p>
        </div>

        <div className="mt-16 bg-white rounded-3xl p-10 border border-slate-100 shadow-sm relative overflow-hidden">
          <h2 className="text-3xl font-black mb-10 flex items-center gap-4 uppercase tracking-tighter text-slate-900">
            Sustainable Operation
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
             <div className="space-y-4 border-l-4 border-indigo-500/10 hover:border-indigo-500/40 transition-colors pl-6">
               <h3 className="font-bold text-blue-600 flex items-center gap-2 small-caps">Why It Happens</h3>
               <p className="text-xs leading-relaxed text-slate-500 font-medium">Confusion between router bands, blocked queues, or driver mismatches are common causes of connected-but-not-printing errors.</p>
             </div>
             <div className="space-y-4 border-l-4 border-indigo-500/10 hover:border-indigo-500/40 transition-colors pl-6">
               <h3 className="font-bold text-blue-600 flex items-center gap-2 small-caps">Maintenance Plan</h3>
               <p className="text-xs leading-relaxed text-slate-500 font-medium">Keep software updated, use stable networks, and clear failed jobs immediately to prevent recurrences.</p>
             </div>
          </div>
        </div>
      </div>
    ),
  },
];

// ── Main Component ─────────────────────────────────────────────────────────
const PrinterSetupGuide = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(0);
  const contentRef = useRef(null);

  // Read ?page=N from URL and activate that content panel
  useEffect(() => {
    const pageParam = searchParams.get('page');
    if (pageParam !== null) {
      const pageIndex = parseInt(pageParam, 10);
      if (!isNaN(pageIndex) && pageIndex >= 0 && pageIndex < pages.length) {
        setCurrentPage(pageIndex);
        // Small delay to let DOM settle, then scroll to content
        setTimeout(() => {
          contentRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 150);
      }
    }
  }, [searchParams]);

  useEffect(() => {
    document.title = "123 HP Com Setup Guide | Step-by-Step HP Printer Setup";
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute("content", "Learn how to complete 123 HP com setup with step-by-step instructions for printer installation, Wi-Fi connection, driver download, and first-time setup.");
    }
  }, []);

  const goToPage = (index) => {
    setCurrentPage(index);
    setTimeout(() => {
      contentRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 50);
  };

  const heroImages = ["/type/p-type1.jpg", "/type/p-type2.jpg", "/type/p-type3.jpg"];

  const productTypes = [
    { icon: Printer, active: true },
    { icon: Monitor },
    { icon: Tablet },
    { icon: Smartphone },
  ];

  const troubleshootingLinks = [
    { icon: () => <PrinterSVGIcon badge={CheckCircle2} />, label: 'Printer Setup Issues' },
    { icon: () => <PrinterSVGIcon badge={Power} />, label: 'Printer Offline Issues' },
    { icon: () => <Wifi size={48} strokeWidth={1.5} color="#0045acff" />, label: 'WiFi Connection Errors' },
    { icon: () => <PaperSVGIcon badge={XCircle} />, label: 'Paper Jam Errors' },
    { icon: () => <PrinterSVGIcon badge={Hourglass} />, label: 'Print Jobs Stuck in Queue' },
    { icon: ScannerSVGIcon, label: 'Scanner Malfunctions' },
  ];

  const setupBanners = [
    { id: 'b1', title: 'Download the Latest Software', description: 'Get the newest drivers and printer software optimized for compatibility with your system.', image: '/guide/banner1.jpg' },
    { id: 'b2', title: 'Connect Your Printer', description: "Establish a connection using a USB cable or set up wireless access through the printer's Wi-Fi setup options.", image: '/guide/banner2.jpg' },
    { id: 'b3', title: 'Install the Printer Drivers', description: 'Proceed with the on-screen instructions to finalize the installation and complete the setup process.', image: '/guide/banner3.jpg' },
    { id: 'b4', title: 'Test the Printer', description: 'After installation, print a test page to verify that your printer is functioning correctly.', image: '/guide/banner4.jpg' },
  ];

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-800 selection:bg-indigo-100 selection:text-indigo-900">

      {/* ── 1. STEALTH PROGRESS BAR ────────────────────────────────────── */}
      <div className="bg-white/80 backdrop-blur-md sticky top-0 z-[80] border-b border-slate-200/60 py-4 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="bg-white/40 backdrop-blur-md px-6 py-2 rounded-full border border-white/60 shadow-sm flex items-center gap-10">
             <div className="flex items-center gap-3">
               <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs font-black">1</div>
               <div className="flex flex-col">
                 <span className="text-[9px] uppercase font-black tracking-widest text-blue-600 leading-tight">Phase 01</span>
                 <span className="text-xs font-bold text-slate-900">Identify</span>
               </div>
               <ChevronRight size={12} className="text-slate-300 ml-1" />
             </div>
             <div className="flex items-center gap-3 opacity-30">
               <div className="w-8 h-8 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center text-xs font-black">2</div>
               <div className="flex flex-col">
                 <span className="text-[9px] uppercase font-black tracking-widest text-slate-400 leading-tight">Phase 02</span>
                 <span className="text-xs font-bold text-slate-400">Download</span>
               </div>
               <ChevronRight size={12} className="text-slate-300 ml-1" />
             </div>
             <div className="flex items-center gap-3 opacity-30">
               <div className="w-8 h-8 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center text-xs font-black">3</div>
               <div className="flex flex-col">
                 <span className="text-[9px] uppercase font-black tracking-widest text-slate-400 leading-tight">Phase 03</span>
                 <span className="text-xs font-bold text-slate-400">Install</span>
               </div>
             </div>
          </div>
          
          <div className="flex items-center gap-6 bg-white/40 backdrop-blur-md p-1.5 rounded-full border border-white/30 shadow-sm">
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-4">Architecture:</span>
            <div className="flex gap-1">
              {productTypes.map((type, idx) => (
                <button key={idx} className={`w-9 h-9 rounded-full flex items-center justify-center transition-all ${type.active ? 'bg-gradient-to-br from-blue-600 to-purple-600 text-white shadow-lg shadow-blue-200/50' : 'text-slate-400 hover:text-blue-600 hover:bg-white/80'}`}>
                  <type.icon size={16} />
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* ── 2. ELITE HERO ────────────────────────────────────────────────── */}
      <section className="relative overflow-hidden pt-24 pb-32 px-6 bg-white">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[120%] h-[700px] bg-[radial-gradient(circle_at_50%_0%,rgba(79,70,229,0.08)_0%,transparent_70%)] pointer-events-none" />
        
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="inline-flex items-center gap-2 bg-blue-50/50 backdrop-blur-md border border-blue-100/50 px-4 py-1.5 rounded-full text-[10px] font-black tracking-[0.2em] text-blue-600 uppercase mb-10">
            <Zap size={10} /> Optimal Workflow Protocol
          </motion.div>
          <h1 className="text-5xl md:text-7xl font-black text-slate-900 mb-8 leading-[1.05] tracking-tighter">
            Precision <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">Printer Setup</span> Intelligence
          </h1>
          <p className="text-xl text-slate-400 mb-12 leading-relaxed max-w-2xl mx-auto font-medium">
             Next-generation setup protocols for modern hardware. Select <strong className="text-slate-900 font-extrabold">Initialize Protocol</strong> to start the optimization sequence.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6 mb-20">
            <button 
              onClick={() => navigate('/find-printer')} 
              className="w-full sm:w-auto bg-gradient-to-r from-blue-600 to-purple-600 text-white px-12 py-5 rounded-full font-black transition-all shadow-[0_20px_40px_-10px_rgba(37,99,235,0.4)] hover:scale-[1.02] active:scale-95 flex items-center justify-center gap-3 group text-center relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-white/10 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity" />
              <span className="relative z-10">Initialize Protocol</span> <ArrowRight size={18} className="relative z-10 group-hover:translate-x-1 transition-transform" />
            </button>
            <button onClick={() => contentRef.current?.scrollIntoView({ behavior: 'smooth' })} className="w-full sm:w-auto bg-white/60 backdrop-blur-md border border-slate-200 text-slate-400 px-10 py-5 rounded-full font-bold hover:border-blue-200 hover:text-blue-600 hover:bg-white transition-all shadow-sm">
              View Documentation
            </button>
          </div>

          <div className="relative group max-w-2xl mx-auto">
            <div className="absolute inset-0 bg-indigo-200/30 blur-[120px] rounded-full scale-75 animate-pulse" />
            <div className="relative z-10 bg-white/40 backdrop-blur-xl border border-white/60 rounded-[4rem] p-12 shadow-2xl shadow-indigo-100/20">
              <button onClick={() => setCurrentSlide((p) => (p - 1 + heroImages.length) % heroImages.length)} className="absolute left-6 top-1/2 -translate-y-1/2 z-20 w-14 h-14 bg-white/80 backdrop-blur-md rounded-2xl shadow-xl flex items-center justify-center text-slate-400 hover:text-blue-600 transition-all opacity-0 group-hover:opacity-100 -translate-x-4 group-hover:translate-x-0">
                <ChevronLeft size={28} />
              </button>
              <AnimatePresence mode="wait">
                <motion.div key={currentSlide} initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.9 }} transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }} className="w-full h-[300px] flex items-center justify-center">
                  <img src={heroImages[currentSlide]} alt="Unit Hardware" className="max-w-full max-h-full object-contain filter drop-shadow-[0_25px_50px_rgba(0,0,0,0.15)]" />
                </motion.div>
              </AnimatePresence>
              <button onClick={() => setCurrentSlide((p) => (p + 1) % heroImages.length)} className="absolute right-6 top-1/2 -translate-y-1/2 z-20 w-14 h-14 bg-white/80 backdrop-blur-md rounded-2xl shadow-xl flex items-center justify-center text-slate-400 hover:text-blue-600 transition-all opacity-0 group-hover:opacity-100 translate-x-4 group-hover:translate-x-0">
                <ChevronRight size={28} />
              </button>
              <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 flex gap-3 z-20 bg-white/80 backdrop-blur-md p-2 rounded-full border border-white shadow-lg">
                {heroImages.map((_, idx) => (
                  <button key={idx} onClick={() => setCurrentSlide(idx)} className={`h-2 rounded-full transition-all duration-500 ${currentSlide === idx ? 'w-10 bg-blue-600' : 'w-2 bg-slate-200 hover:bg-indigo-200'}`} />
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── 3. DIAGNOSTIC MATRIX ─────────────────────────────────────────── */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-end gap-6 mb-16 px-4">
            <div className="max-w-xl">
               <span className="text-[10px] font-black text-blue-600 uppercase tracking-widest mb-2 block">System Integrity</span>
               <h2 className="text-3xl font-black text-slate-900">Troubleshooting Matrix</h2>
            </div>
            <p className="text-sm text-slate-400 max-w-sm text-right">Identify hardware or software bottlenecks through our specialized diagnostic shortcuts.</p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-6">
            {troubleshootingLinks.map((item, idx) => (
              <motion.div key={idx} whileHover={{ y: -12 }} className="group relative bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm hover:shadow-2xl hover:shadow-indigo-100/30 transition-all duration-300 cursor-pointer flex flex-col items-center justify-center text-center">
                <div className="mb-6 p-4 rounded-2xl bg-white/50 backdrop-blur-md border border-white/20 group-hover:bg-blue-600 group-hover:text-white hover:text-white transition-all duration-300">
                  <item.icon />
                </div>
                <h3 className="text-[10px] font-black text-slate-800 uppercase tracking-[0.2em] leading-tight px-2">{item.label}</h3>
                <div className="absolute top-6 right-6 text-[10px] font-black text-slate-200 group-hover:text-blue-600/20 transition-colors tracking-widest">0{idx + 1}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── 4. DEPLOYMENT STEPS ───────────────────────────────────────────── */}
      <section className="py-24 bg-slate-50 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {setupBanners.map((banner, idx) => (
              <motion.div key={banner.id} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: idx * 0.1 }} className="group bg-white rounded-[3rem] p-8 border border-slate-100 shadow-sm hover:shadow-xl transition-all h-full flex flex-col items-center text-center">
                <div className="w-24 h-24 mb-8 rounded-[2rem] overflow-hidden shadow-lg transform group-hover:scale-110 transition-transform bg-slate-100">
                  <img src={banner.image} alt={banner.title} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" />
                </div>
                <h3 className="text-sm font-black text-slate-900 mb-3 tracking-tight small-caps">{banner.title}</h3>
                <p className="text-xs text-slate-500 leading-relaxed font-medium">{banner.description}</p>
                <div className="mt-auto pt-6 opacity-0 group-hover:opacity-100 transition-opacity">
                   <div className="w-10 h-1 rounded-full bg-blue-600 mx-auto" />
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── 5. CONTENT ARCHITECTURE ─────────────────────────────────────── */}
      <section ref={contentRef} className="bg-white py-32 scroll-mt-24 border-y border-slate-100 relative">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-indigo-600/10 to-transparent" />
        <div className="max-w-5xl mx-auto px-6">
          
          <div className="flex items-center justify-center gap-2 mb-16">
            {pages.map((_, idx) => (
              <button key={idx} onClick={() => goToPage(idx)} className={`group relative h-1.5 rounded-full transition-all duration-500 overflow-hidden ${currentPage === idx ? 'w-24 bg-blue-600 shadow-[0_0_15px_rgba(79,70,229,0.3)]' : 'w-12 bg-slate-100 hover:bg-slate-200'}`}>
                <div className="absolute inset-0 bg-indigo-400 opacity-0 group-hover:opacity-20" />
              </button>
            ))}
          </div>

          <AnimatePresence mode="wait">
            <motion.div key={currentPage} initial={{ opacity: 0, scale: 0.98, y: 30 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.98, y: -20 }} transition={{ duration: 0.4, ease: "circOut" }}>
              {pages[currentPage].content}
            </motion.div>
          </AnimatePresence>

          <div className="flex items-center justify-between mt-24 px-6 py-6 bg-slate-50/50 rounded-[2.5rem] border border-slate-100">
            <button 
              onClick={() => goToPage(currentPage - 1)} 
              disabled={currentPage === 0} 
              className={`h-12 flex items-center gap-3 px-6 rounded-xl font-bold transition-all relative overflow-hidden group/btn ${
                currentPage === 0 
                  ? 'opacity-20 grayscale pointer-events-none' 
                  : 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-xl shadow-blue-200/50 hover:scale-[1.02] active:scale-95'
              }`}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-indigo-600/5 to-blue-600/5 opacity-0 group-hover/btn:opacity-100 transition-opacity" />
              <ChevronLeft size={18} className="relative z-10" /> <span className="hidden sm:inline text-sm relative z-10">Previous</span>
            </button>

            <div className="flex flex-col items-center">
               <span className="text-[9px] font-black text-blue-600 uppercase tracking-[0.2em] mb-1 opacity-60">Phase Sequence</span>
               <div className="text-lg font-black text-slate-900 tracking-tighter">0{currentPage + 1} <span className="text-slate-300 mx-1">/</span> 0{pages.length}</div>
            </div>

            <button 
              onClick={() => goToPage(currentPage + 1)} 
              disabled={currentPage === pages.length - 1} 
              className={`h-12 flex items-center gap-3 px-8 rounded-full flex items-center gap-3 px-8 font-bold transition-all relative overflow-hidden group/btn ${
                currentPage === pages.length - 1 
                  ? 'opacity-20 grayscale pointer-events-none' 
                  : 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-xl shadow-blue-200/50 hover:scale-[1.02] active:scale-95'
              }`}
            >
              <div className="absolute inset-0 bg-white/10 backdrop-blur-sm opacity-0 group-hover/btn:opacity-100 transition-opacity" />
              <span className="hidden sm:inline text-sm relative z-10">Next Phase</span> <ChevronRight size={18} className="relative z-10" />
            </button>
          </div>
        </div>
      </section>

      {/* ── 6. EXECUTIVE CONSULTATION ───────────────────────────────────── */}
      <section className="py-32 px-6 bg-slate-900 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-full h-full bg-[radial-gradient(circle_at_100%_0%,rgba(79,70,229,0.1)_0%,transparent_60%)] pointer-events-none" />
        <div className="max-w-6xl mx-auto flex flex-col lg:flex-row items-center gap-20 relative z-10">
          <div className="flex-1 space-y-8 text-center lg:text-left">
            <span className="inline-block px-4 py-1 rounded-full bg-white/5 border border-white/10 text-[10px] font-black text-indigo-400 uppercase tracking-[0.2em] italic">Direct Support Channel</span>
            <h2 className="text-4xl md:text-5xl font-black text-white leading-tight tracking-tighter">Still Encountering <span className="text-indigo-400 italic font-medium">Friction?</span></h2>
            <p className="text-lg text-slate-400 leading-relaxed max-w-xl mx-auto lg:mx-0">Connect with our elite diagnostic team for real-time architectural optimization. Avoid unnecessary hardware downtime with specialized remote assistance.</p>
            <button 
              onClick={() => setIsChatOpen(true)} 
              className="w-full sm:w-auto bg-gradient-to-r from-blue-600 to-purple-600 text-white px-12 py-5 rounded-full font-black transition-all shadow-[0_20px_40px_-10px_rgba(37,99,235,0.4)] hover:scale-[1.02] active:scale-95 flex items-center justify-center gap-4 mx-auto lg:mx-0 relative overflow-hidden group"
            >
               <div className="absolute inset-0 bg-white/10 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity" />
               <span className="relative z-10">Establish Live Connection</span> <MessageSquare size={20} className="relative z-10 group-hover:rotate-12 transition-transform" />
            </button>
          </div>
          <div className="flex-1 w-full max-w-xl relative">
            <div className="absolute -inset-4 bg-indigo-500/20 blur-3xl rounded-full animate-pulse" />
            <div className="relative rounded-[4rem] overflow-hidden shadow-2xl border-[12px] border-white/5">
              <img src="/guide/banner5.jpg" alt="Support Specialist" className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700 hover:scale-105" />
            </div>
            <div className="absolute -bottom-6 -right-6 bg-white p-6 rounded-3xl shadow-2xl flex items-center gap-4 max-w-[240px]">
               <div className="w-3 h-3 rounded-full bg-green-500 animate-ping absolute top-0 -left-1" />
               <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-blue-600 font-bold">24</div>
               <p className="text-[10px] font-black text-slate-900 leading-tight uppercase tracking-widest">Active <br/>Diagnostic Support</p>
            </div>
          </div>
        </div>
      </section>

      {/* ── DISCLAIMER BAR ───────────────────────────────────────────────── */}
      <div className="bg-[#0045acff] py-6 px-6">
        <p className="text-white text-sm text-center max-w-4xl mx-auto leading-relaxed">
          Prints Matrix operates as an independent third-party retailer. Manufacturer warranties, where applicable, are provided directly by the respective brands. Prints Matrix does not claim authorization or official partnership with any manufacturer unless explicitly stated.
        </p>
      </div>

      {/* ── 8. CHAT INTERFACE ─────────────────────────────────────────── */}
      <AnimatePresence>
        {isChatOpen && (
          <motion.div initial={{ opacity: 0, y: 100, scale: 0.9 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 100, scale: 0.9 }} className="fixed bottom-10 right-10 z-[150] w-[380px] max-w-[90vw] bg-white rounded-[3rem] shadow-[0_35px_80px_rgba(0,0,0,0.15)] border border-slate-100 overflow-hidden flex flex-col h-[550px]">
            <div className="bg-slate-900 p-8 flex items-center justify-between text-white relative">
              <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/10 rounded-full -mr-12 -mt-12" />
              <div className="flex items-center gap-4 relative z-10">
                <div className="relative">
                  <div className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center border border-white/10"><MessageSquare size={20} /></div>
                  <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-400 border-4 border-slate-900 rounded-full" />
                </div>
                <div>
                  <p className="font-black text-xs uppercase tracking-widest">Live Diagnostics</p>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest opacity-80 italic">Status: Secure & Active</p>
                </div>
              </div>
              <button onClick={() => setIsChatOpen(false)} className="w-10 h-10 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-white/60 transition-colors"><X size={20} /></button>
            </div>
            <div className="flex-1 p-8 bg-slate-50 overflow-y-auto space-y-6">
              <div className="bg-white p-5 rounded-[2rem] rounded-tl-none shadow-sm text-xs font-medium text-slate-700 border border-slate-100 leading-relaxed italic">
                 Protocol Initiated. Welcome to live diagnostic support. How can we assist with your hardware optimization today?
              </div>
            </div>
            <div className="p-6 bg-white border-t border-slate-100 flex gap-3">
              <input type="text" placeholder="State your requirements..." className="flex-1 bg-slate-100 rounded-2xl px-6 py-4 text-xs font-bold outline-none border border-transparent focus:border-indigo-600/20 focus:bg-white transition-all placeholder:text-slate-400" />
              <button className="w-14 h-14 rounded-2xl bg-blue-600 text-white flex items-center justify-center shadow-lg shadow-indigo-200 hover:scale-110 active:scale-95 transition-all"><Send size={18} /></button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default PrinterSetupGuide;
